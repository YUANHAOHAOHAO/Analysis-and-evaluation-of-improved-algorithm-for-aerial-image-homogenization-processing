I = imread('original.jpg');   
I= rgb2gray(I);
imshow(I);