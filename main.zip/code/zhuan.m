I=rgb2gray(imread('original.jpg'));
f=im2double(I);
g=im2double(f);
h=uint8(round(f*255));
figure;
%subplot(1,2,1),imshow(g);
subplot(1,2,2),imshow(h);
