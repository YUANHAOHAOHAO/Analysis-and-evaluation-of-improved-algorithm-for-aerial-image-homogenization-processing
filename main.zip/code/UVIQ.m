clc
clear all
close all
 
img =imread('original.jpg');
R_data = img(:,:,1);
G_data = img(:,:,2);
B_data = img(:,:,3);
 
 
[row,col,dep]=size(img);%ƥ��������
 
Gray_data =img;
YCbCr =img;
YUV =img;
 
Y_data =zeros(row,col);
Cb_data=zeros(row,col);
Cr_data=zeros(row,col);
 
Y1_data =zeros(row,col);
U_data=zeros(row,col);
V_data=zeros(row,col);
%rgbתycbcr
for r =1:row
    for c =1:col
        Y_data(r, c) = 0.299*R_data(r, c) + 0.587*G_data(r, c) + 0.114*B_data(r, c);
        Cb_data(r, c) = -0.172*R_data(r, c) - 0.339*G_data(r, c) + 0.511*B_data(r, c) + 128;
        Cr_data(r, c) = 0.511*R_data(r, c) - 0.428*G_data(r, c) - 0.083*B_data(r,c)+ 128;
    end
end
%rgbתyuv
for r =1:row
    for c =1:col
        Y1_data(r, c)  = 0.183*R_data(r, c) + 0.614*G_data(r, c) + 0.062*B_data(r, c)+16;
        U_data(r, c) = -0.101*R_data(r, c) - 0.338*G_data(r, c) + 0.439*B_data(r, c) + 128;
        V_data(r, c) = 0.439*R_data(r, c) - 0.399*G_data(r, c) - 0.040*B_data(r,c)+ 128;
    end
end
 
 
 
YCbCr(:,:,1)=Y_data;
YCbCr(:,:,2)=Cb_data;
YCbCr(:,:,3)=Cr_data;
 
YUV(:,:,1)=Y1_data;
YUV(:,:,2)=U_data;
YUV(:,:,3)=V_data;
 
Gray_data(:,:,1)=Y_data;
Gray_data(:,:,2)=Y_data;
Gray_data(:,:,3)=Y_data;
 
figure,
%subplot(221),imshow(img),title('img');
%subplot(222),imshow(Gray_data),title('Gray');
subplot(223),imshow(YUV),title('YUV��ɫģ��');
%subplot(224),imshow(YCbCr),title('YCbCr');
disp('=================ת�����===============')