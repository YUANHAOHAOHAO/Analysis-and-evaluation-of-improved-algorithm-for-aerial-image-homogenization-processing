function outImg = contrastStretch( origImg, value )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
origImg = double(origImg);
if value >= 0
    outImg = 255*(origImg - value)/(255-2*value);
else
    outImg = ((255 + 2 * value)/255)*origImg - value;
end

outImg(outImg < 0) = 0;
outImg(outImg >255) = 255;
outImg = uint8(outImg);

end

