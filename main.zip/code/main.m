Img = imread('original.jpg');%ImgΪunit8
% figure(1);
% subplot(2,2,1);imshow(Img);title('ԭʼͼ��');
% figure(2);
% subplot(1,2,1);imshow(Img);title('ԭʼͼ��');

Img = double(Img);
[m,n,p] = size(Img);
%% MASK�ȹ�
offset = mean(mean(Img));%�ֱ��С���ȡƽ��
for i = 1:p
    backImg(:,:,i) = double(lowfilt(Img(:,:,i),3,0.01,0));%��p���ͨ�˲�
    outImg(:,:,i) = Img(:,:,i) - backImg(:,:,i) + offset(:,:,i); %p���ȹ�ͼ
end
figure(1);
% subplot(2,2,2);imshow(uint8(backImg));title('����ͼ��');
% subplot(2,2,3);imshow(uint8(outImg));title('����ǰ�ȹ���');
% % imwrite(uint8(outImg),'�������.jpg');
% outImg = contrastStretch( outImg, 20 );
% subplot(2,2,4);imshow(outImg);title('MASK�ȹ���');
%imwrite(uint8(outImg),'MASK�ȹ���.jpg');
outImg = contrastStretch( outImg, 10 );
imshow(outImg);title('MASK�ȹ���');
%% Wallis�ȹ�
mg = zeros(m,n,p);
num = 1;
M = m/num;
N = n/num;
for i = 0:(num - 1)
    for j = 0:(num - 1)
        mg(i*M+1:(i+1)*M,j*N+1:(j+1)*N,:) = repmat( sum(sum(Img(i*M+1:(i+1)*M,j*N+1:(j+1)*N,:)))/(M*N),M,N);
    end
end
% mg = mg;
sg = (Img - mg).^2;
for i = 0:(num - 1)
    for j = 0:(num - 1)
        sg(i*M+1:(i+1)*M,j*N+1:(j+1)*N,:) = repmat( sum(sum(sg(i*M+1:(i+1)*M,j*N+1:(j+1)*N,:))),M,N);
    end
end
sg = sqrt(sg/(M*N));
     
mf = max(max(mg));

for i = 1:p
temp = sg(mg(:,:,i) == mf(:,:,i));
sf(1,1,i) = temp(1);

waillisImg(:,:,i) = (Img(:,:,i) - mg(:,:,i)) .* (sf(:,:,i) ./ (sg(:,:,i)+ eps)) + mf(:,:,i);
end
waillisImg = matchRange( waillisImg );
figure(2);
imshow(uint8(waillisImg));title('Wallis�ȹ���');
%imwrite(uint8(waillisImg),'Wallis�ȹ���.jpg');


