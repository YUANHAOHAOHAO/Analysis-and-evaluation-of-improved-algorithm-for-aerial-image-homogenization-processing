I=imread('original.jpg');
I=rgb2gray(I);
figure,imshow(I);